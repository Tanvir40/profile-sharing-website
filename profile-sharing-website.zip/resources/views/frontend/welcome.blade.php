@include('../frontend/inc/header')



<div class="">
    <div class="row">
        <div class="col-md-12">
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                  

                </div>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img width="100%" height="500px" src="{{asset('frontend/img/1600w-cVzLo3B1IHE.webp')}}" class="d-block w-100" alt="...">
                  </div>
                  
                </div>
                
                
              </div>
        </div>
    </div>
</div>



<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="image text-center mt-5">
                <h2 style="margin-bottom:100px;">Star Member</h2>
            </div>
            
            <!-- <div class=" d-flex align-items-center justify-content-center" style="margin-top:80px;">
                
                
                
            </div> -->
        <div class="row">
            <div class="col-md-3 ">

            </div>

            <div class="col-md-6">
                <div class="box text-center text-white px-5 pb-3" style="width: 35rem;padding-top:4rem;background-color:#003B86;border-radius: 10px;">
                    <img class="z-index:1;" style="border: 4px solid white;width:120px;border-radius: 50%; margin-top: -200px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                    <div class="d-flex align-items-center justify-content-center">
                        <h4>@SabbirAhmedSaby &nbsp;</h4>
                    
                    </div>
                    <div class="d-flex">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo tempore omnis dolore, harum mollitia quisquam sapiente libero laudantium</p>
                </div>
                <div class="row m-0 p-0">
                    
                    <div class="col-4">
                        <img class="footers z-index:1;"height="100" style="border: 4px solid white;width:100px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                    </div>

                    <div class="col-4">
                        <iframe class="videos" style="border-radius: 10px;" width="100" height="100" src="https://www.youtube.com/embed/OqtR1ZlEHwY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    </div>

                    <div class="col-4">
                        <img  height="100" class="footers z-index:1;" style="border: 4px solid white;width:100px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                    </div>

                </div>  
                </div>
            </div>

            <div class="col-md-3">
                
            </div>
        </div>

        </div>


<div class="container">

        <div class="text-center mt-5">
            <h4 class="mb-5">New Members</h4>
        </div>

        <div class="row d-flex ">

            <div class="text-center col-3">
               
            </div>
       
            <div class="text-center col-6 d-flex">

               <div class="row">

                    <div class="col-md-6 col-sm-12 mb-5">
                        <div class="card mb-6" style="background-color: #003B86;">
                            <div class="card-body">
                                <img class="z-index:1;" style="border: 4px solid white;width:70px;border-radius: 50%; margin-top: -70px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                <h6 class="text-white bold">@tanvir Hasan Tonmoy</h6>
                                <p class="text-white fw-light" style="font-size:0.8rem;">Lorem ipsum dolor sit amet consectetur</p>

                                <div class="row m-0 p-0">
                    
                                    <div class="col-4">
                                        <img class="footer z-index:1;"height="50" style="border: 4px solid white;width:50px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                    </div>
                
                                    <div class="col-4">
                                        <iframe class="video" style="border-radius: 10px;" width="70" height="50" src="https://www.youtube.com/embed/OqtR1ZlEHwY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    </div>
                
                                    <div class="col-4">
                                        <img  height="50" class="footer z-index:1;" style="border: 4px solid white;width:50px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                    </div>
                
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12 mb-5">
                        <div class="card mb-6" style="background-color: #003B86;">
                            <div class="card-body">
                                <img class="z-index:1;" style="border: 4px solid white;width:70px;border-radius: 50%; margin-top: -70px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                <h6 class="text-white bold">@tanvir Hasan Tonmoy</h6>
                                <p class="text-white fw-light" style="font-size:0.8rem;">Lorem ipsum dolor sit amet consectetur</p>

                                <div class="row m-0 p-0">
                    
                                    <div class="col-4">
                                        <img class="footer z-index:1;"height="50" style="border: 4px solid white;width:50px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                    </div>
                
                                    <div class="col-4">
                                        <iframe class="video" style="border-radius: 10px;" width="70" height="50" src="https://www.youtube.com/embed/OqtR1ZlEHwY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    </div>
                
                                    <div class="col-4">
                                        <img  height="50" class="footer z-index:1;" style="border: 4px solid white;width:50px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                    </div>
                
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12 mb-5">
                        <div class="card mb-6" style="background-color: #003B86;">
                            <div class="card-body">
                                <img class="z-index:1;" style="border: 4px solid white;width:70px;border-radius: 50%; margin-top: -70px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                <h6 class="text-white bold">@tanvir Hasan Tonmoy</h6>
                                <p class="text-white fw-light" style="font-size:0.8rem;">Lorem ipsum dolor sit amet consectetur</p>

                                <div class="row m-0 p-0">
                    
                                    <div class="col-4">
                                        <img class="footer z-index:1;"height="50" style="border: 4px solid white;width:50px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                    </div>
                
                                    <div class="col-4">
                                        <iframe class="video" style="border-radius: 10px;" width="70" height="50" src="https://www.youtube.com/embed/OqtR1ZlEHwY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    </div>
                
                                    <div class="col-4">
                                        <img  height="50" class="footer z-index:1;" style="border: 4px solid white;width:50px;" src="{{asset('frontend/img/saby.jpg')}}" alt="">
                                    </div>
                
                                </div>
                            </div>
                        </div>
                    </div>

                   
                    
                </div>

            </div>

            

            <div class="text-center col-3">
            
            </div>

        </div>

        
       
    </div>
        

    </div>
</div>

@include('./frontend/inc/footer')